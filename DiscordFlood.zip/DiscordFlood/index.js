/*
 * ═══════════════════════════════════════════════
 *         Discord DM Bot - by nana
 * ═══════════════════════════════════════════════
 *  TAG: nana
 *  Desenvolvido com ❤️
 * ═══════════════════════════════════════════════
 */

require('dotenv').config();
const { Client, GatewayIntentBits } = require('discord.js');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.DirectMessages,
  ],
});

const DISCORD_TOKEN = process.env.DISCORD_TOKEN;
const USER_ID = process.env.USER_ID;
const MESSAGE_COUNT = 500;
const DELAY_MS = 1000;

if (!DISCORD_TOKEN) {
  console.error('ERROR: DISCORD_TOKEN environment variable is not set!');
  console.error('Please set your Discord bot token in the Secrets tab.');
  process.exit(1);
}

if (!USER_ID) {
  console.error('ERROR: USER_ID environment variable is not set!');
  console.error('Please set the target user ID in the Secrets tab.');
  process.exit(1);
}

client.once('ready', async () => {
  console.log(`✅ Bot is ready! Logged in as ${client.user.tag}`);
  console.log(`📤 Starting to send ${MESSAGE_COUNT} DM messages...`);
  
  try {
    const user = await client.users.fetch(USER_ID);
    
    if (!user) {
      console.error('❌ Invalid user ID or user not found');
      process.exit(1);
    }

    console.log(`📝 Sending DMs to user: ${user.tag}`);
    
    let successCount = 0;
    let failCount = 0;

    for (let i = 1; i <= MESSAGE_COUNT; i++) {
      try {
        await user.send(`Message ${i} of ${MESSAGE_COUNT}`);
        successCount++;
        
        if (i % 50 === 0) {
          console.log(`✅ Progress: ${i}/${MESSAGE_COUNT} messages sent`);
        }
        
        if (i < MESSAGE_COUNT) {
          await new Promise(resolve => setTimeout(resolve, DELAY_MS));
        }
      } catch (error) {
        failCount++;
        console.error(`❌ Failed to send message ${i}:`, error.message);
        
        if (error.message.includes('rate limit')) {
          console.log('⏸️  Rate limited, waiting 10 seconds...');
          await new Promise(resolve => setTimeout(resolve, 10000));
          i--;
        } else if (error.message.includes('Cannot send messages to this user')) {
          console.error('❌ Cannot send DMs to this user. They may have DMs disabled or have blocked the bot.');
          process.exit(1);
        }
      }
    }
    
    console.log('\n🎉 Finished sending messages!');
    console.log(`✅ Successfully sent: ${successCount}`);
    console.log(`❌ Failed: ${failCount}`);
    console.log('\nBot will stay online. Press Ctrl+C to stop.');
    
  } catch (error) {
    console.error('❌ Error fetching user:', error.message);
    process.exit(1);
  }
});

client.on('error', error => {
  console.error('Discord client error:', error);
});

console.log('🚀 Starting Discord bot...');
client.login(DISCORD_TOKEN);
