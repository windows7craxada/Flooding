# Discord DM Bot

## Overview
A Discord bot that automatically sends 500 direct messages (DMs) to a specified Discord user. The bot includes progress logging, error handling, and rate limit management.

## Recent Changes
- **2025-11-18**: Added author signature/tag "nana" to all files
  - Added header comment with "TAG: nana" in index.js
  - Added footer signature in LEIA-ME.txt
  - Updated author field in package.json to "nana"
  - Recreated discord-bot.tar.gz with updated files

- **2025-11-18**: Updated to send DMs instead of channel messages
  - Modified bot to send direct messages to a user
  - Changed CHANNEL_ID to USER_ID environment variable
  - Updated intents to support DirectMessages
  - Improved error handling for DM-specific issues (blocked users, disabled DMs)
  - Increased rate limit wait time to 10 seconds for DMs

- **2025-11-18**: Initial project setup
  - Created Discord bot using discord.js
  - Implemented message sending functionality with 500 message target
  - Added rate limit handling and error management
  - Included progress logging every 50 messages
  - Configured 1-second delay between messages to avoid rate limits

## Project Architecture
- **Language**: Node.js 20
- **Main Library**: discord.js v14
- **Entry Point**: index.js

## Setup Instructions
1. Create a Discord bot at https://discord.com/developers/applications
2. Enable the following intents in the Bot settings:
   - SERVER MEMBERS INTENT (optional)
   - MESSAGE CONTENT INTENT (optional)
3. Set the following secrets in Replit:
   - `DISCORD_TOKEN`: Your Discord bot token
   - `USER_ID`: The ID of the user who should receive the DMs
4. Run the bot

## Features
- Sends 500 DMs to a specified user
- Progress updates every 50 messages
- 1-second delay between messages
- Rate limit detection and handling
- Error recovery for DM-specific issues
- Message counter tracking

## How to Get User ID
1. Enable Developer Mode in Discord (User Settings → Advanced → Developer Mode)
2. Right-click on the user and select "Copy User ID"

## Important Notes
- The recipient must have DMs enabled from server members or have the bot as a friend
- The recipient must not have blocked the bot
- Sending 500 DMs may trigger Discord's spam detection
